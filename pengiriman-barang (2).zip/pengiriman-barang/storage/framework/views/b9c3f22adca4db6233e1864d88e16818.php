<img
    src=" <?php echo e(asset('images/tj-logo1.png')); ?>"
    alt="Tunas Jaya logo"
    class="w-16"><?php /**PATH D:\College\TA Project\TA Pengiriman\pengiriman-barang\pengiriman-barang\resources\views/vendor/filament-panels/components/logo.blade.php ENDPATH**/ ?>