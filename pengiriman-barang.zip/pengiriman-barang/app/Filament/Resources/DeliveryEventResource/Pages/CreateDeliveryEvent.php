<?php

namespace App\Filament\Resources\DeliveryEventResource\Pages;

use App\Filament\Resources\DeliveryEventResource;
use Filament\Actions;
use Filament\Resources\Pages\CreateRecord;

class CreateDeliveryEvent extends CreateRecord
{
    protected static string $resource = DeliveryEventResource::class;
}
