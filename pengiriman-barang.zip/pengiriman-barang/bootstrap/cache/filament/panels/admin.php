<?php return array (
  'livewireComponents' => 
  array (
    'app.filament.resources.checkpoint-resource.pages.create-checkpoint' => 'App\\Filament\\Resources\\CheckpointResource\\Pages\\CreateCheckpoint',
    'app.filament.resources.checkpoint-resource.pages.edit-checkpoint' => 'App\\Filament\\Resources\\CheckpointResource\\Pages\\EditCheckpoint',
    'app.filament.resources.checkpoint-resource.pages.list-checkpoints' => 'App\\Filament\\Resources\\CheckpointResource\\Pages\\ListCheckpoints',
    'app.filament.resources.delivery-event-resource.pages.create-delivery-event' => 'App\\Filament\\Resources\\DeliveryEventResource\\Pages\\CreateDeliveryEvent',
    'app.filament.resources.delivery-event-resource.pages.edit-delivery-event' => 'App\\Filament\\Resources\\DeliveryEventResource\\Pages\\EditDeliveryEvent',
    'app.filament.resources.delivery-event-resource.pages.list-delivery-events' => 'App\\Filament\\Resources\\DeliveryEventResource\\Pages\\ListDeliveryEvents',
    'app.filament.resources.delivery-resource.pages.create-delivery' => 'App\\Filament\\Resources\\DeliveryResource\\Pages\\CreateDelivery',
    'app.filament.resources.delivery-resource.pages.edit-delivery' => 'App\\Filament\\Resources\\DeliveryResource\\Pages\\EditDelivery',
    'app.filament.resources.delivery-resource.pages.list-deliveries' => 'App\\Filament\\Resources\\DeliveryResource\\Pages\\ListDeliveries',
    'app.filament.resources.delivery-resource.relation-managers.delivery-events-relation-manager' => 'App\\Filament\\Resources\\DeliveryResource\\RelationManagers\\DeliveryEventsRelationManager',
    'app.filament.resources.delivery-status-resource.pages.create-delivery-status' => 'App\\Filament\\Resources\\DeliveryStatusResource\\Pages\\CreateDeliveryStatus',
    'app.filament.resources.delivery-status-resource.pages.edit-delivery-status' => 'App\\Filament\\Resources\\DeliveryStatusResource\\Pages\\EditDeliveryStatus',
    'app.filament.resources.delivery-status-resource.pages.list-delivery-statuses' => 'App\\Filament\\Resources\\DeliveryStatusResource\\Pages\\ListDeliveryStatuses',
    'app.filament.resources.district-resource.pages.create-district' => 'App\\Filament\\Resources\\DistrictResource\\Pages\\CreateDistrict',
    'app.filament.resources.district-resource.pages.edit-district' => 'App\\Filament\\Resources\\DistrictResource\\Pages\\EditDistrict',
    'app.filament.resources.district-resource.pages.list-districts' => 'App\\Filament\\Resources\\DistrictResource\\Pages\\ListDistricts',
    'app.filament.resources.user-resource.pages.create-user' => 'App\\Filament\\Resources\\UserResource\\Pages\\CreateUser',
    'app.filament.resources.user-resource.pages.edit-user' => 'App\\Filament\\Resources\\UserResource\\Pages\\EditUser',
    'app.filament.resources.user-resource.pages.list-users' => 'App\\Filament\\Resources\\UserResource\\Pages\\ListUsers',
    'app.filament.pages.auth.edit-profile' => 'App\\Filament\\Pages\\Auth\\EditProfile',
    'filament.pages.dashboard' => 'Filament\\Pages\\Dashboard',
    'filament.widgets.account-widget' => 'Filament\\Widgets\\AccountWidget',
    'filament.widgets.filament-info-widget' => 'Filament\\Widgets\\FilamentInfoWidget',
    'filament.livewire.database-notifications' => 'Filament\\Livewire\\DatabaseNotifications',
    'filament.pages.auth.edit-profile' => 'Filament\\Pages\\Auth\\EditProfile',
    'filament.livewire.global-search' => 'Filament\\Livewire\\GlobalSearch',
    'filament.livewire.notifications' => 'Filament\\Livewire\\Notifications',
    'filament.pages.auth.email-verification.email-verification-prompt' => 'Filament\\Pages\\Auth\\EmailVerification\\EmailVerificationPrompt',
    'filament.pages.auth.login' => 'Filament\\Pages\\Auth\\Login',
    'filament.pages.auth.password-reset.request-password-reset' => 'Filament\\Pages\\Auth\\PasswordReset\\RequestPasswordReset',
    'filament.pages.auth.password-reset.reset-password' => 'Filament\\Pages\\Auth\\PasswordReset\\ResetPassword',
    'filament.pages.auth.register' => 'Filament\\Pages\\Auth\\Register',
    'bezhan-salleh.filament-shield.resources.role-resource.pages.list-roles' => 'BezhanSalleh\\FilamentShield\\Resources\\RoleResource\\Pages\\ListRoles',
    'bezhan-salleh.filament-shield.resources.role-resource.pages.create-role' => 'BezhanSalleh\\FilamentShield\\Resources\\RoleResource\\Pages\\CreateRole',
    'bezhan-salleh.filament-shield.resources.role-resource.pages.view-role' => 'BezhanSalleh\\FilamentShield\\Resources\\RoleResource\\Pages\\ViewRole',
    'bezhan-salleh.filament-shield.resources.role-resource.pages.edit-role' => 'BezhanSalleh\\FilamentShield\\Resources\\RoleResource\\Pages\\EditRole',
  ),
  'clusters' => 
  array (
  ),
  'clusteredComponents' => 
  array (
  ),
  'clusterDirectories' => 
  array (
  ),
  'clusterNamespaces' => 
  array (
  ),
  'pages' => 
  array (
    0 => 'Filament\\Pages\\Dashboard',
  ),
  'pageDirectories' => 
  array (
    0 => 'D:\\College\\TA Project\\TA Pengiriman\\pengiriman-barang\\pengiriman-barang\\app\\Filament/Pages',
  ),
  'pageNamespaces' => 
  array (
    0 => 'App\\Filament\\Pages',
  ),
  'resources' => 
  array (
    'D:\\College\\TA Project\\TA Pengiriman\\pengiriman-barang\\pengiriman-barang\\app\\Filament\\Resources\\CheckpointResource.php' => 'App\\Filament\\Resources\\CheckpointResource',
    'D:\\College\\TA Project\\TA Pengiriman\\pengiriman-barang\\pengiriman-barang\\app\\Filament\\Resources\\DeliveryEventResource.php' => 'App\\Filament\\Resources\\DeliveryEventResource',
    'D:\\College\\TA Project\\TA Pengiriman\\pengiriman-barang\\pengiriman-barang\\app\\Filament\\Resources\\DeliveryResource.php' => 'App\\Filament\\Resources\\DeliveryResource',
    'D:\\College\\TA Project\\TA Pengiriman\\pengiriman-barang\\pengiriman-barang\\app\\Filament\\Resources\\DeliveryStatusResource.php' => 'App\\Filament\\Resources\\DeliveryStatusResource',
    'D:\\College\\TA Project\\TA Pengiriman\\pengiriman-barang\\pengiriman-barang\\app\\Filament\\Resources\\DistrictResource.php' => 'App\\Filament\\Resources\\DistrictResource',
    'D:\\College\\TA Project\\TA Pengiriman\\pengiriman-barang\\pengiriman-barang\\app\\Filament\\Resources\\UserResource.php' => 'App\\Filament\\Resources\\UserResource',
    0 => 'BezhanSalleh\\FilamentShield\\Resources\\RoleResource',
  ),
  'resourceDirectories' => 
  array (
    0 => 'D:\\College\\TA Project\\TA Pengiriman\\pengiriman-barang\\pengiriman-barang\\app\\Filament/Resources',
  ),
  'resourceNamespaces' => 
  array (
    0 => 'App\\Filament\\Resources',
  ),
  'widgets' => 
  array (
    0 => 'Filament\\Widgets\\AccountWidget',
    1 => 'Filament\\Widgets\\FilamentInfoWidget',
  ),
  'widgetDirectories' => 
  array (
    0 => 'D:\\College\\TA Project\\TA Pengiriman\\pengiriman-barang\\pengiriman-barang\\app\\Filament/Widgets',
  ),
  'widgetNamespaces' => 
  array (
    0 => 'App\\Filament\\Widgets',
  ),
);