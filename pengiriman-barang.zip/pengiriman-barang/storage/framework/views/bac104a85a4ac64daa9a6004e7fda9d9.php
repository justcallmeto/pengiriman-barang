<div
    <?php echo e($attributes
            ->merge([
                'id' => $getId(),
            ], escape: false)
            ->merge($getExtraAttributes(), escape: false)); ?>

>
    <?php echo e($getChildComponentContainer()); ?>

</div>
<?php /**PATH D:\College\TA Project\TA Pengiriman\pengiriman-barang\pengiriman-barang\vendor\filament\forms\src\/../resources/views/components/group.blade.php ENDPATH**/ ?>